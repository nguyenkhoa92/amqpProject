namespace Security
{
	public sealed class Startup
	{
		private Startup(){}

		[System.STAThread]
		static void Main()
		{
			MainForm frmMain = new MainForm();
			System.Windows.Forms.Application.Run(frmMain);
			frmMain.Dispose();
		}
	}
}