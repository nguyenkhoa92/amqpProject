namespace Security
{
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ToolTip MyToolTip;
		private System.Windows.Forms.OpenFileDialog MyOpenFileDialog;

		private System.Windows.Forms.Label lblTitle1;
		private System.Windows.Forms.Label lblTitle2;
		private System.Windows.Forms.Label lblTitle3;
		private System.Windows.Forms.Label lblTitle4;
		private System.Windows.Forms.Label lblTitle5;
		private System.Windows.Forms.Label lblTitle6;

		private System.Windows.Forms.CheckBox chkMD5Hash;
		private System.Windows.Forms.CheckBox chkSHA1Hash;

		private System.Windows.Forms.TextBox txtMD5HashData;
		private System.Windows.Forms.TextBox txtSHA1HashData;

		private System.Windows.Forms.Button btnOpen;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.TextBox txtFileName;
		private System.Windows.Forms.CheckBox chkUpperCase;
		private System.Windows.Forms.Button btnExit;

		private System.ComponentModel.IContainer components = null;

		public MainForm()
		{
			InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if(disposing)
				if(components != null)
					components.Dispose();

			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnOpen = new System.Windows.Forms.Button();
			this.MyOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.txtMD5HashData = new System.Windows.Forms.TextBox();
			this.txtSHA1HashData = new System.Windows.Forms.TextBox();
			this.MyToolTip = new System.Windows.Forms.ToolTip(this.components);
			this.lblTitle1 = new System.Windows.Forms.Label();
			this.lblTitle2 = new System.Windows.Forms.Label();
			this.lblTitle3 = new System.Windows.Forms.Label();
			this.lblTitle4 = new System.Windows.Forms.Label();
			this.lblTitle5 = new System.Windows.Forms.Label();
			this.lblTitle6 = new System.Windows.Forms.Label();
			this.chkSHA1Hash = new System.Windows.Forms.CheckBox();
			this.chkMD5Hash = new System.Windows.Forms.CheckBox();
			this.btnClear = new System.Windows.Forms.Button();
			this.txtFileName = new System.Windows.Forms.TextBox();
			this.chkUpperCase = new System.Windows.Forms.CheckBox();
			this.btnExit = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnOpen
			// 
			this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.btnOpen.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnOpen.ForeColor = System.Drawing.Color.Navy;
			this.btnOpen.Location = new System.Drawing.Point(120, 224);
			this.btnOpen.Name = "btnOpen";
			this.btnOpen.Size = new System.Drawing.Size(440, 24);
			this.btnOpen.TabIndex = 11;
			this.btnOpen.Text = "&Open File";
			this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
			// 
			// txtMD5HashData
			// 
			this.txtMD5HashData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtMD5HashData.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtMD5HashData.ForeColor = System.Drawing.Color.Navy;
			this.txtMD5HashData.Location = new System.Drawing.Point(120, 176);
			this.txtMD5HashData.Name = "txtMD5HashData";
			this.txtMD5HashData.ReadOnly = true;
			this.txtMD5HashData.Size = new System.Drawing.Size(440, 21);
			this.txtMD5HashData.TabIndex = 13;
			this.txtMD5HashData.Text = "";
			this.txtMD5HashData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.MyToolTip.SetToolTip(this.txtMD5HashData, "MD5 Hash");
			// 
			// txtSHA1HashData
			// 
			this.txtSHA1HashData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtSHA1HashData.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtSHA1HashData.ForeColor = System.Drawing.Color.Navy;
			this.txtSHA1HashData.Location = new System.Drawing.Point(120, 200);
			this.txtSHA1HashData.Name = "txtSHA1HashData";
			this.txtSHA1HashData.ReadOnly = true;
			this.txtSHA1HashData.Size = new System.Drawing.Size(440, 21);
			this.txtSHA1HashData.TabIndex = 14;
			this.txtSHA1HashData.Text = "";
			this.txtSHA1HashData.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.MyToolTip.SetToolTip(this.txtSHA1HashData, "SHA-1 Hash");
			// 
			// lblTitle1
			// 
			this.lblTitle1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle1.ForeColor = System.Drawing.Color.Navy;
			this.lblTitle1.Location = new System.Drawing.Point(8, 8);
			this.lblTitle1.Name = "lblTitle1";
			this.lblTitle1.Size = new System.Drawing.Size(550, 16);
			this.lblTitle1.TabIndex = 1;
			this.lblTitle1.Text = "Created By Dariush Tasdighi from Iran - Tehran";
			this.lblTitle1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblTitle2
			// 
			this.lblTitle2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle2.ForeColor = System.Drawing.Color.Navy;
			this.lblTitle2.Location = new System.Drawing.Point(8, 32);
			this.lblTitle2.Name = "lblTitle2";
			this.lblTitle2.Size = new System.Drawing.Size(550, 16);
			this.lblTitle2.TabIndex = 2;
			this.lblTitle2.Text = "Version: 1.0.4 - Date: 11 Feb. 2005";
			this.lblTitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblTitle3
			// 
			this.lblTitle3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle3.ForeColor = System.Drawing.Color.Navy;
			this.lblTitle3.Location = new System.Drawing.Point(8, 56);
			this.lblTitle3.Name = "lblTitle3";
			this.lblTitle3.Size = new System.Drawing.Size(550, 16);
			this.lblTitle3.TabIndex = 3;
			this.lblTitle3.Text = "Support: DariushT@GMail.com";
			this.lblTitle3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblTitle4
			// 
			this.lblTitle4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle4.ForeColor = System.Drawing.Color.Navy;
			this.lblTitle4.Location = new System.Drawing.Point(8, 80);
			this.lblTitle4.Name = "lblTitle4";
			this.lblTitle4.Size = new System.Drawing.Size(550, 16);
			this.lblTitle4.TabIndex = 4;
			this.lblTitle4.Text = "Support: Dariush@IranianExperts.com";
			this.lblTitle4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblTitle5
			// 
			this.lblTitle5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle5.ForeColor = System.Drawing.Color.Navy;
			this.lblTitle5.Location = new System.Drawing.Point(8, 104);
			this.lblTitle5.Name = "lblTitle5";
			this.lblTitle5.Size = new System.Drawing.Size(550, 16);
			this.lblTitle5.TabIndex = 5;
			this.lblTitle5.Text = "Homepage: http://www.IranianExperts.com";
			this.lblTitle5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblTitle6
			// 
			this.lblTitle6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTitle6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTitle6.ForeColor = System.Drawing.Color.Navy;
			this.lblTitle6.Location = new System.Drawing.Point(8, 128);
			this.lblTitle6.Name = "lblTitle6";
			this.lblTitle6.Size = new System.Drawing.Size(550, 16);
			this.lblTitle6.TabIndex = 6;
			this.lblTitle6.Text = "Yahoo Group: http://groups.yahoo.com/group/IranianExperts";
			this.lblTitle6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// chkSHA1Hash
			// 
			this.chkSHA1Hash.Checked = true;
			this.chkSHA1Hash.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkSHA1Hash.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.chkSHA1Hash.ForeColor = System.Drawing.Color.Navy;
			this.chkSHA1Hash.Location = new System.Drawing.Point(8, 200);
			this.chkSHA1Hash.Name = "chkSHA1Hash";
			this.chkSHA1Hash.Size = new System.Drawing.Size(104, 16);
			this.chkSHA1Hash.TabIndex = 9;
			this.chkSHA1Hash.Text = "SHA-1 Hash";
			// 
			// chkMD5Hash
			// 
			this.chkMD5Hash.Checked = true;
			this.chkMD5Hash.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkMD5Hash.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.chkMD5Hash.ForeColor = System.Drawing.Color.Navy;
			this.chkMD5Hash.Location = new System.Drawing.Point(8, 176);
			this.chkMD5Hash.Name = "chkMD5Hash";
			this.chkMD5Hash.Size = new System.Drawing.Size(104, 16);
			this.chkMD5Hash.TabIndex = 8;
			this.chkMD5Hash.Text = "MD5 Hash";
			// 
			// btnClear
			// 
			this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.btnClear.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnClear.ForeColor = System.Drawing.Color.Navy;
			this.btnClear.Location = new System.Drawing.Point(8, 224);
			this.btnClear.Name = "btnClear";
			this.btnClear.Size = new System.Drawing.Size(104, 24);
			this.btnClear.TabIndex = 10;
			this.btnClear.Text = "&Clear";
			this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
			// 
			// txtFileName
			// 
			this.txtFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtFileName.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtFileName.ForeColor = System.Drawing.Color.Navy;
			this.txtFileName.Location = new System.Drawing.Point(120, 152);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.ReadOnly = true;
			this.txtFileName.Size = new System.Drawing.Size(440, 21);
			this.txtFileName.TabIndex = 12;
			this.txtFileName.Text = "";
			this.txtFileName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.MyToolTip.SetToolTip(this.txtFileName, "Filename");
			// 
			// chkUpperCase
			// 
			this.chkUpperCase.Checked = true;
			this.chkUpperCase.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkUpperCase.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.chkUpperCase.ForeColor = System.Drawing.Color.Navy;
			this.chkUpperCase.Location = new System.Drawing.Point(8, 152);
			this.chkUpperCase.Name = "chkUpperCase";
			this.chkUpperCase.Size = new System.Drawing.Size(104, 16);
			this.chkUpperCase.TabIndex = 7;
			this.chkUpperCase.Text = "Upper Case";
			this.chkUpperCase.CheckedChanged += new System.EventHandler(this.chkUpperCase_CheckedChanged);
			// 
			// btnExit
			// 
			this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnExit.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnExit.ForeColor = System.Drawing.Color.Navy;
			this.btnExit.Location = new System.Drawing.Point(8, 8);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(104, 24);
			this.btnExit.TabIndex = 0;
			this.btnExit.Text = "E&xit";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnExit;
			this.ClientSize = new System.Drawing.Size(566, 251);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.chkUpperCase);
			this.Controls.Add(this.txtFileName);
			this.Controls.Add(this.btnClear);
			this.Controls.Add(this.chkMD5Hash);
			this.Controls.Add(this.chkSHA1Hash);
			this.Controls.Add(this.lblTitle6);
			this.Controls.Add(this.lblTitle5);
			this.Controls.Add(this.lblTitle4);
			this.Controls.Add(this.lblTitle3);
			this.Controls.Add(this.lblTitle2);
			this.Controls.Add(this.lblTitle1);
			this.Controls.Add(this.txtSHA1HashData);
			this.Controls.Add(this.txtMD5HashData);
			this.Controls.Add(this.btnOpen);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Get File\'s Hash";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnExit_Click(object sender, System.EventArgs e)
		{
			System.Windows.Forms.Application.Exit();
		}

		private void btnClear_Click(object sender, System.EventArgs e)
		{
			txtFileName.Text = "";

			txtMD5HashData.Text = "";
			txtSHA1HashData.Text = "";
		}

		private void chkUpperCase_CheckedChanged(object sender, System.EventArgs e)
		{
			if(chkUpperCase.Checked)
			{
				txtMD5HashData.Text = txtMD5HashData.Text.ToUpper();
				txtSHA1HashData.Text = txtSHA1HashData.Text.ToUpper();
			}
			else
			{
				txtMD5HashData.Text = txtMD5HashData.Text.ToLower();
				txtSHA1HashData.Text = txtSHA1HashData.Text.ToLower();
			}
		}

		private void btnOpen_Click(object sender, System.EventArgs e)
		{
			MyOpenFileDialog.Filter = "All Files|*.*";
			if(MyOpenFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				txtFileName.Text = System.IO.Path.GetFileName(MyOpenFileDialog.FileName);

				if(chkMD5Hash.Checked)
				{
					if(chkUpperCase.Checked)
						txtMD5HashData.Text = IranianExperts.DTHasher.GetMD5Hash(MyOpenFileDialog.FileName).ToUpper();
					else
						txtMD5HashData.Text = IranianExperts.DTHasher.GetMD5Hash(MyOpenFileDialog.FileName).ToLower();
				}

				if(chkSHA1Hash.Checked)
				{
					if(chkUpperCase.Checked)
						txtSHA1HashData.Text = IranianExperts.DTHasher.GetSHA1Hash(MyOpenFileDialog.FileName).ToUpper();
					else
						txtSHA1HashData.Text = IranianExperts.DTHasher.GetSHA1Hash(MyOpenFileDialog.FileName).ToLower();
				}
			}
		}
	}
}