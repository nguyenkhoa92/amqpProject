Moved to https://github.com/alanxz/rabbitmq-c
